use anyhow::{Context, Result};
use bson::{doc, oid::ObjectId, DateTime as BsonDateTime};
use chrono::Utc;
use mongodb::{
    options::{ClientOptions, FindOneAndUpdateOptions, ReturnDocument},
    Client, Collection, Database,
};

use crate::{
    config::MongoConfig,
    models::{
        AudioRecording, MetarEntry, ProcessingJob,
        QualityResult, QualityStatus, Site, Transcription,
    },
};

// ---------------------------------------------------------------------------
// Db handle
// ---------------------------------------------------------------------------

#[derive(Clone, Debug)]
pub struct Db {
    pub database: Database,
}

impl Db {
    pub async fn connect(cfg: &MongoConfig) -> Result<Self> {
        let opts = ClientOptions::parse(&cfg.uri)
            .await
            .context("Failed to parse MongoDB URI")?;

        let client = Client::with_options(opts)
            .context("Failed to create MongoDB client")?;

        client
            .database("admin")
            .run_command(doc! { "ping": 1 }, None)
            .await
            .context("MongoDB ping failed")?;

        tracing::info!("Connected to MongoDB Atlas (db: {})", cfg.database);

        let database = client.database(&cfg.database);
        Ok(Self { database })
    }

    // -----------------------------------------------------------------------
    // Collection accessors
    // -----------------------------------------------------------------------

    pub fn audio_recordings(&self) -> Collection<AudioRecording> {
        self.database.collection("audio_recordings")
    }

    pub fn transcriptions(&self) -> Collection<Transcription> {
        self.database.collection("transcriptions")
    }

    pub fn metar_entries(&self) -> Collection<MetarEntry> {
        self.database.collection("metar_entries")
    }

    pub fn processing_jobs(&self) -> Collection<ProcessingJob> {
        self.database.collection("processing_jobs")
    }

    pub fn sites(&self) -> Collection<Site> {
        self.database.collection("sites")
    }

    // -----------------------------------------------------------------------
    // Index setup
    // -----------------------------------------------------------------------

    pub async fn ensure_indexes(&self) -> Result<()> {
        use mongodb::IndexModel;
        use mongodb::options::IndexOptions;

        // audio_recordings — poll by pipeline_status
        self.audio_recordings().create_index(
            IndexModel::builder()
                .keys(doc! { "pipeline_status": 1, "created": 1 })
                .options(IndexOptions::builder().name("pipeline_status_created".to_string()).build())
                .build(),
            None,
        ).await?;

        self.audio_recordings().create_index(
            IndexModel::builder()
                .keys(doc! { "site_id": 1, "recorded": -1 })
                .options(IndexOptions::builder().name("site_recorded".to_string()).build())
                .build(),
            None,
        ).await?;

        // transcriptions
        self.transcriptions().create_index(
            IndexModel::builder()
                .keys(doc! { "audio_recording_id": 1 })
                .options(IndexOptions::builder().name("audio_recording_id".to_string()).build())
                .build(),
            None,
        ).await?;

        // metar_entries
        self.metar_entries().create_index(
            IndexModel::builder()
                .keys(doc! { "site_id": 1, "observed_at": -1 })
                .options(IndexOptions::builder().name("site_observed".to_string()).build())
                .build(),
            None,
        ).await?;

        self.metar_entries().create_index(
            IndexModel::builder()
                .keys(doc! { "quality_status": 1 })
                .options(IndexOptions::builder().name("quality_status".to_string()).build())
                .build(),
            None,
        ).await?;

        tracing::info!("MongoDB indexes ensured");
        Ok(())
    }

    // -----------------------------------------------------------------------
    // Site loading
    // -----------------------------------------------------------------------

    pub async fn load_sites(&self) -> Result<std::collections::HashMap<String, Site>> {
        use futures::TryStreamExt;
        let mut cursor = self.sites().find(None, None).await?;
        let mut map = std::collections::HashMap::new();
        while let Some(site) = cursor.try_next().await? {
            map.insert(site.id.clone(), site);
        }
        tracing::info!("Loaded {} sites from database", map.len());
        Ok(map)
    }

    // -----------------------------------------------------------------------
    // Transcribe job
    // -----------------------------------------------------------------------

    /// Atomically claim one "raw" audio_recording for transcription.
    pub async fn claim_for_transcription(&self) -> Result<Option<AudioRecording>> {
        let opts = FindOneAndUpdateOptions::builder()
            .sort(doc! { "created": 1 })
            .return_document(ReturnDocument::After)
            .build();

        let result = self.audio_recordings()
            .find_one_and_update(
                doc! { "pipeline_status": "raw" },
                doc! {
                    "$set": {
                        "pipeline_status": "transcribing",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                opts,
            )
            .await
            .context("claim_for_transcription failed")?;

        Ok(result)
    }

    /// Insert transcription document and update audio_recording status.
    pub async fn save_transcription(
        &self,
        recording_id: ObjectId,
        tx: &Transcription,
    ) -> Result<ObjectId> {
        // Insert transcription document
        let result = self.transcriptions()
            .insert_one(tx, None)
            .await
            .context("Failed to insert transcription")?;

        let tx_id = result.inserted_id.as_object_id()
            .context("Transcription insert returned no ObjectId")?;

        // Update audio_recording status
        self.audio_recordings()
            .update_one(
                doc! { "_id": recording_id },
                doc! {
                    "$set": {
                        "pipeline_status": "transcribed",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                None,
            )
            .await?;

        Ok(tx_id)
    }

    pub async fn mark_transcription_failed(&self, id: ObjectId, error: &str) -> Result<()> {
        self.audio_recordings()
            .update_one(
                doc! { "_id": id },
                doc! {
                    "$set": {
                        "pipeline_status": "failed",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                        "error": error,
                    }
                },
                None,
            )
            .await?;
        Ok(())
    }

    // -----------------------------------------------------------------------
    // Parse job
    // -----------------------------------------------------------------------

    /// Claim one "transcribed" recording for parsing.
    /// Returns the AudioRecording and its associated Transcription.
    pub async fn claim_for_parsing(&self) -> Result<Option<(AudioRecording, Transcription)>> {
        let opts = FindOneAndUpdateOptions::builder()
            .sort(doc! { "last_update": 1 })
            .return_document(ReturnDocument::After)
            .build();

        let recording = self.audio_recordings()
            .find_one_and_update(
                doc! { "pipeline_status": "transcribed" },
                doc! {
                    "$set": {
                        "pipeline_status": "parsing",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                opts,
            )
            .await
            .context("claim_for_parsing failed")?;

        let recording = match recording {
            Some(r) => r,
            None    => return Ok(None),
        };

        // Fetch associated transcription
        let tx = self.transcriptions()
            .find_one(
                doc! { "audio_recording_id": recording.id.unwrap() },
                None,
            )
            .await?
            .context("No transcription found for recording")?;

        Ok(Some((recording, tx)))
    }

    /// Insert MetarEntry and update audio_recording status to "parsed".
    pub async fn save_metar_entry(
        &self,
        recording_id: ObjectId,
        metar: &MetarEntry,
    ) -> Result<ObjectId> {
        let result = self.metar_entries()
            .insert_one(metar, None)
            .await
            .context("Failed to insert metar entry")?;

        let metar_id = result.inserted_id.as_object_id()
            .context("MetarEntry insert returned no ObjectId")?;

        self.audio_recordings()
            .update_one(
                doc! { "_id": recording_id },
                doc! {
                    "$set": {
                        "pipeline_status": "parsed",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                None,
            )
            .await?;

        Ok(metar_id)
    }

    pub async fn mark_parse_failed(&self, id: ObjectId, error: &str) -> Result<()> {
        self.audio_recordings()
            .update_one(
                doc! { "_id": id },
                doc! {
                    "$set": {
                        "pipeline_status": "failed",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                        "error": error,
                    }
                },
                None,
            )
            .await?;
        Ok(())
    }

    // -----------------------------------------------------------------------
    // Trim job
    // -----------------------------------------------------------------------

    /// Claim one "parsed" recording for trimming.
    /// Returns AudioRecording, Transcription, and selected_loop_time from metar entry.
    pub async fn claim_for_trim(&self) -> Result<Option<(AudioRecording, Transcription, Option<String>)>> {
        let opts = FindOneAndUpdateOptions::builder()
            .sort(doc! { "last_update": 1 })
            .return_document(ReturnDocument::After)
            .build();

        let recording = self.audio_recordings()
            .find_one_and_update(
                doc! { "pipeline_status": "parsed" },
                doc! {
                    "$set": {
                        "pipeline_status": "trimming",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                opts,
            )
            .await
            .context("claim_for_trim failed")?;

        let recording = match recording {
            Some(r) => r,
            None    => return Ok(None),
        };

        let recording_id = recording.id.unwrap();

        // Fetch transcription for word timestamps
        let tx = self.transcriptions()
            .find_one(doc! { "audio_recording_id": recording_id }, None)
            .await?
            .context("No transcription found for recording")?;

        // Fetch selected_loop_time from metar entry
        let selected_loop_time = self.metar_entries()
            .find_one(doc! { "audio_recording_id": recording_id }, None)
            .await?
            .and_then(|m| m.selected_loop_time);

        Ok(Some((recording, tx, selected_loop_time)))
    }

    /// Update audio_recording with trimmed audio location and status.
    pub async fn save_trimmed_audio(
        &self,
        recording_id: ObjectId,
        trimmed_bucket: &str,
        trimmed_key: &str,
    ) -> Result<()> {
        self.audio_recordings()
            .update_one(
                doc! { "_id": recording_id },
                doc! {
                    "$set": {
                        "pipeline_status": "trimmed",
                        "trimmed_audio": {
                            "bucket":     trimmed_bucket,
                            "object_key": trimmed_key,
                        },
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                None,
            )
            .await?;
        Ok(())
    }

    pub async fn mark_trim_failed(&self, id: ObjectId, error: &str) -> Result<()> {
        self.audio_recordings()
            .update_one(
                doc! { "_id": id },
                doc! {
                    "$set": {
                        "pipeline_status": "failed",
                        "last_update": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                        "error": error,
                    }
                },
                None,
            )
            .await?;
        Ok(())
    }

    // -----------------------------------------------------------------------
    // Quality job
    // -----------------------------------------------------------------------

    /// Claim one metar_entry with quality_status "pending" for quality review.
    pub async fn claim_for_quality(&self) -> Result<Option<(MetarEntry, Transcription)>> {
        let opts = FindOneAndUpdateOptions::builder()
            .sort(doc! { "updated_at": 1 })
            .return_document(ReturnDocument::After)
            .build();

        let metar = self.metar_entries()
            .find_one_and_update(
                doc! { "quality_status": "pending" },
                doc! {
                    "$set": {
                        "quality_status": "processing",
                        "updated_at": BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                opts,
            )
            .await
            .context("claim_for_quality failed")?;

        let metar = match metar {
            Some(m) => m,
            None    => return Ok(None),
        };

        // Fetch transcription for quality agent context
        let tx = self.transcriptions()
            .find_one(
                doc! { "audio_recording_id": metar.audio_recording_id },
                None,
            )
            .await?
            .context("No transcription found for metar entry")?;

        Ok(Some((metar, tx)))
    }

    pub async fn save_quality_result(
        &self,
        metar_id:     ObjectId,
        quality:      &QualityResult,
        status:       QualityStatus,
    ) -> Result<()> {
        let quality_bson = bson::to_bson(quality)?;
        let status_bson  = bson::to_bson(&status)?;

        self.metar_entries()
            .update_one(
                doc! { "_id": metar_id },
                doc! {
                    "$set": {
                        "quality_status": status_bson,
                        "quality":        quality_bson,
                        "updated_at":     BsonDateTime::from_millis(Utc::now().timestamp_millis()),
                    }
                },
                None,
            )
            .await?;
        Ok(())
    }
}
